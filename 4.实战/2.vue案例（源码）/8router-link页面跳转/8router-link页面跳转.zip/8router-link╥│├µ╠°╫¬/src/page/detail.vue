<template>
	<div class="detail-page">
		<div class="video">
			<video src="http://v3.mukewang.com/shizhan/59f8498ae420e5be578b459b/H.mp4" controls="controls"></video>
			<router-link to="/">
				<div class="video-back"><</div>
			</router-link>
		</div>
	</div>
</template>
<style scoped>
	.video{
		position: relative;
		height: 3.82rem;
	}
	.video video{
		width: 100%;
		height: 100%;
	}
	.video-back{
		position: absolute;
		top: 0.42rem;
		left: 0.32rem;
		text-align: center;
		color: #fff;
		font-size: 0.36rem;
		line-height: 0.64rem;
		border-radius: 3px;
		width: 0.64rem;
		height: 0.64rem;
		background: rgba(0,0,0,.5);
	}
</style>